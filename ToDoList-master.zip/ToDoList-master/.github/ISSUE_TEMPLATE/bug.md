---
name: Bug
about: Create a bug-report to help address errors in the repo.
title: ''
labels: bug
assignees: 'tusharnankani'

---

**Description**

<!--A clear and concise description of what the bug is.-->

**Screenshots**

<!-- Please add a screenshot, if applicable.-->

**Additional Context**

<!-- Add any other context about the problem here.-->


